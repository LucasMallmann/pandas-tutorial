Estudo sobre DataScience.

Este projeto inclui a an�lise do pre�o de casas nos EUA, e como elas se comportam ao longo dos anos.

Este projeto foi criado para estudos de DataScience utilizando Python, incluindo suas principais bibliotecas
de "Science" (ex: Pandas, Matplotlib, ScikitLearn)

Os dados foram extra�dos do website Quandl, que oferece alguns dados abertos para an�lise, atrav�s de uma API.